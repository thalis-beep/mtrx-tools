Nectar "Alive Again" V2 - Premiere Pro project

1. Unzip every part. All parts unpack into the same "Nectar_V2_Premiere" folder; if your computer
   makes extra folders (e.g. "Nectar_V2_Premiere 2"), move their media files into
   Nectar_V2_Premiere/media so all files sit together.
2. In Premiere: File > Import > Nectar_Alive_Again_V2.xml
3. If Premiere asks to locate media, point it to any file in the media folder; the rest relink.

Sequence: 1080x1920, 30 fps, 2:44.85
  V1  the 49 animated shots, cut on the beat
  V2  captions (TikTok Sans Bold, transparent PNGs, one per phrase)
  V3  callouts (ZERO SUGAR, ZERO CALORIES, NON-GMO, BIOPERINE) and the end title
  A1  the song (intro trimmed, 1:28-1:38 raised ~2 dB, fade-out on the end card)
Each shot clip keeps its extra frames, so cuts can be slipped or extended.
